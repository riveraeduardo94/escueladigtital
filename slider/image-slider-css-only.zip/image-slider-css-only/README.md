# Image slider css only

A Pen created on CodePen.io. Original URL: [https://codepen.io/sandra90/pen/xwMGgB](https://codepen.io/sandra90/pen/xwMGgB).

